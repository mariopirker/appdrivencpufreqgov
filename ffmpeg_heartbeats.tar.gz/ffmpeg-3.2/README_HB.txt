This package includes three components.

1) FFMPEG with ffplay
2) Heartbeat framwork
3) Polling application



Build-

In order to build correctly please follow the order 

1) Heartbeat framework

untar the archive.
 
cd ffmpeg-3.2/heartbeats
make

this will build heartbeat framwork library


2) FFMPEG

go up one level to FFMPEG directory. and build ffmpeg using these commands

../
./configure --extra-libs='-L./heartbeats/lib -lhb-shared'
make
sudo make install


3) Polling application

cc get_hertrate.c -o get_hertrate


Now you can play video files using ffplay. and from a sepearte terminal you can run ./get_heartrat and it will
provide you heartbeat information



How system work

ffplay will send one heartbeat for each successfully decoded frame from 'get_video_frame()' function. ffplay and get_heartrate
communicate over named pipes to exchange current heartbeat information.
